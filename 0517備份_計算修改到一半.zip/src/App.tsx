import React from 'react';
import { ConfigProvider } from 'antd';
import zhTW from 'antd/lib/locale/zh_TW';
import Header from './components/Header';
import Footer from './components/Footer';
import StartPage from './pages/StartPage';
import IntroPage from './pages/IntroPage';
import TestPage from './pages/TestPage';
import ResultsPage from './pages/ResultsPage';
import VideoPage from './pages/VideoPage';
import SurveyPage from './pages/SurveyPage';
import CompletedPage from './pages/CompletedPage';
import useTestLogic from './hooks/useTestLogic';
import { TEST_PHASES } from './constants/testConstants';
import "./styles/main.css";
import "./styles/biased-products.css";

// 注册 ECharts 必須的組件
import { BarChart, LineChart } from 'echarts/charts';
import { GridComponent, TooltipComponent, TitleComponent, LegendComponent } from 'echarts/components';
import * as echarts from 'echarts/core';
import { CanvasRenderer } from 'echarts/renderers';

echarts.use([
  TitleComponent,
  TooltipComponent,
  GridComponent,
  LegendComponent,
  BarChart,
  LineChart,
  CanvasRenderer
]);

function App() {
  const {
    currentPhase,
    currentWord,
    currentWordType,
    feedback,
    testResults,
    testCount,
    maxTestCount,
    showInstructions,
    biasedProduct,
    biasLevel,
    dScore,
    biasedProducts,
    checkAnswer,
    moveToNextPhase,
    startTest,
    calculateBiasResults
  } = useTestLogic({ maxTestCount: 10 });

  // 渲染當前階段的內容
  const renderContent = () => {
    switch (currentPhase) {
      case TEST_PHASES.START:
        return <StartPage onStart={moveToNextPhase} />;
      
      case TEST_PHASES.INTRO:
        return <IntroPage onStart={moveToNextPhase} />;
      
      case TEST_PHASES.GENDER_PRACTICE:
      case TEST_PHASES.PRODUCT_PRACTICE:
      case TEST_PHASES.COMBINED_TEST_1:
      case TEST_PHASES.REVERSED_PRACTICE:
      case TEST_PHASES.COMBINED_TEST_2:
        return (
          <TestPage
            currentPhase={currentPhase}
            currentWord={currentWord}
            feedback={feedback}
            testCount={testCount}
            maxTestCount={maxTestCount}
            showInstructions={showInstructions}
            onCheckAnswer={checkAnswer}
            onStartTest={startTest}
          />
        );
      
      case TEST_PHASES.RESULTS:
        return (
          <ResultsPage
            testResults={testResults}
            biasedProduct={biasedProduct}
            biasLevel={biasLevel}
            dScore={dScore}
            biasedProducts={biasedProducts}
            onContinue={moveToNextPhase}
          />
        );
      
      case TEST_PHASES.VIDEO:
        return <VideoPage onContinue={moveToNextPhase} />;
      
      case TEST_PHASES.SURVEY:
        return <SurveyPage onComplete={moveToNextPhase} />;
      
      case TEST_PHASES.COMPLETED:
        return <CompletedPage onRestart={() => moveToNextPhase()} />;
      
      default:
        return null;
    }
  };

  return (
    <ConfigProvider locale={zhTW}>
      <div className="app-container">
        {/* 頁頭進度條 */}
        <Header currentPhase={currentPhase} />
        
        {/* 主要內容區域 */}
        <div className="app-content">
          <div className="content-wrapper">
            {renderContent()}
          </div>
        </div>
        
        {/* 頁尾 */}
        <Footer />
      </div>
    </ConfigProvider>
  );
}

export default App;