import { useState, useEffect } from 'react';
import { TestPhase, WordType, Side, TestResults, FeedbackType } from '../types/testTypes';
import { TEST_PHASES, maleWords, femaleWords, computerWords, skinCareWords } from '../constants/testConstants';
import { calculateDScore, generateBiasedProducts } from '../utils/biasCalculation';

interface UseTestLogicProps {
  maxTestCount?: number;
}

const useTestLogic = ({ maxTestCount = 10 }: UseTestLogicProps = {}) => {
  const [currentPhase, setCurrentPhase] = useState<TestPhase>(TEST_PHASES.START);
  const [currentWord, setCurrentWord] = useState<string>('');
  const [currentWordType, setCurrentWordType] = useState<WordType | ''>('');
  const [feedback, setFeedback] = useState<FeedbackType>('');
  const [testResults, setTestResults] = useState<TestResults>({
    maleComputer: [],
    femaleSkincare: [],
    femaleComputer: [],
    maleSkincare: []
  });
  const [testCount, setTestCount] = useState<number>(0);
  const [testStartTime, setTestStartTime] = useState<number>(0);
  const [showInstructions, setShowInstructions] = useState<boolean>(true);
  const [biasedProduct, setBiasedProduct] = useState<string>('');
  const [biasLevel, setBiasLevel] = useState<string>('');
  const [dScore, setDScore] = useState<number>(0);
  const [biasedProducts, setBiasedProducts] = useState<Array<{ name: string, score: number }>>([]);
  const [usedWords, setUsedWords] = useState<Set<string>>(new Set());

  // 開始新的測試
  const startNewTest = () => {
    setTestCount(0);
    setShowInstructions(true);
    setUsedWords(new Set());
  };

  // 檢查答案
  const checkAnswer = (side: Side) => {
    const endTime = Date.now();
    const reactionTime = endTime - testStartTime;
    let isCorrect = false;

    // 檢查答案是否正確
    if (currentPhase === TEST_PHASES.GENDER_PRACTICE) {
      isCorrect = (side === 'left' && maleWords.includes(currentWord)) ||
        (side === 'right' && femaleWords.includes(currentWord));
    } else if (currentPhase === TEST_PHASES.PRODUCT_PRACTICE) {
      isCorrect = (side === 'left' && computerWords.includes(currentWord)) ||
        (side === 'right' && skinCareWords.includes(currentWord));
    } else if (currentPhase === TEST_PHASES.COMBINED_TEST_1) {
      isCorrect = (side === 'left' && (maleWords.includes(currentWord) || computerWords.includes(currentWord))) ||
        (side === 'right' && (femaleWords.includes(currentWord) || skinCareWords.includes(currentWord)));
    } else if (currentPhase === TEST_PHASES.REVERSED_PRACTICE) {
      isCorrect = (side === 'left' && femaleWords.includes(currentWord)) ||
        (side === 'right' && maleWords.includes(currentWord));
    } else if (currentPhase === TEST_PHASES.COMBINED_TEST_2) {
      isCorrect = (side === 'left' && (femaleWords.includes(currentWord) || computerWords.includes(currentWord))) ||
        (side === 'right' && (maleWords.includes(currentWord) || skinCareWords.includes(currentWord)));
    }

    // 設置反饋狀態
    setFeedback(isCorrect ? 'correct' : 'incorrect');

    // 如果答案正確
    if (isCorrect) {
      // 記錄反應時間
      if (currentPhase === TEST_PHASES.COMBINED_TEST_1) {
        if (maleWords.includes(currentWord) || computerWords.includes(currentWord)) {
          setTestResults(prev => ({
            ...prev,
            maleComputer: [...prev.maleComputer, reactionTime]
          }));
        } else {
          setTestResults(prev => ({
            ...prev,
            femaleSkincare: [...prev.femaleSkincare, reactionTime]
          }));
        }
      } else if (currentPhase === TEST_PHASES.COMBINED_TEST_2) {
        if (femaleWords.includes(currentWord) || computerWords.includes(currentWord)) {
          setTestResults(prev => ({
            ...prev,
            femaleComputer: [...prev.femaleComputer, reactionTime]
          }));
        } else {
          setTestResults(prev => ({
            ...prev,
            maleSkincare: [...prev.maleSkincare, reactionTime]
          }));
        }
      }

      // 增加測試計數
      const newCount = testCount + 1;
      setTestCount(newCount);

      // 顯示正確反饋後繼續
      setTimeout(() => {
        setFeedback('');
        if (newCount >= maxTestCount) {
          moveToNextPhase();
        } else {
          selectNextWord();
        }
      }, 500);
    } else {
      // 如果答案錯誤，保持當前詞不變，等待正確答案
      setTimeout(() => {
        setFeedback('');
      }, 1000);
    }
  };

  // 選擇下一個詞
  const selectNextWord = () => {
    let wordPool: string[] = [];

    if (currentPhase === TEST_PHASES.GENDER_PRACTICE) {
      wordPool = [...maleWords, ...femaleWords];
    } else if (currentPhase === TEST_PHASES.PRODUCT_PRACTICE) {
      wordPool = [...computerWords, ...skinCareWords];
    } else if (currentPhase === TEST_PHASES.COMBINED_TEST_1 || currentPhase === TEST_PHASES.COMBINED_TEST_2) {
      wordPool = [...maleWords, ...femaleWords, ...computerWords, ...skinCareWords];
    } else if (currentPhase === TEST_PHASES.REVERSED_PRACTICE) {
      wordPool = [...maleWords, ...femaleWords];
    }

    // 過濾掉已使用的詞
    const availableWords = wordPool.filter(word => !usedWords.has(word));

    if (availableWords.length === 0) {
      moveToNextPhase();
      return;
    }

    const randomIndex = Math.floor(Math.random() * availableWords.length);
    const selectedWord = availableWords[randomIndex];

    // 將選中的詞添加到已使用集合中
    setUsedWords(prev => {
      const newSet = new Set(prev);
      newSet.add(selectedWord);
      return newSet;
    });

    let wordType: WordType | '' = '';
    if (maleWords.includes(selectedWord)) {
      wordType = 'male';
    } else if (femaleWords.includes(selectedWord)) {
      wordType = 'female';
    } else if (computerWords.includes(selectedWord)) {
      wordType = 'computer';
    } else if (skinCareWords.includes(selectedWord)) {
      wordType = 'skincare';
    }

    setCurrentWord(selectedWord);
    setCurrentWordType(wordType);
    setTestStartTime(Date.now());
  };

  // 進入下一個測試階段
  const moveToNextPhase = () => {
    switch (currentPhase) {
      case TEST_PHASES.START:
        setCurrentPhase(TEST_PHASES.INTRO);
        break;
      case TEST_PHASES.INTRO:
        setCurrentPhase(TEST_PHASES.GENDER_PRACTICE);
        startNewTest();
        break;
      case TEST_PHASES.GENDER_PRACTICE:
        setCurrentPhase(TEST_PHASES.PRODUCT_PRACTICE);
        startNewTest();
        break;
      case TEST_PHASES.PRODUCT_PRACTICE:
        setCurrentPhase(TEST_PHASES.COMBINED_TEST_1);
        startNewTest();
        break;
      case TEST_PHASES.COMBINED_TEST_1:
        setCurrentPhase(TEST_PHASES.REVERSED_PRACTICE);
        startNewTest();
        break;
      case TEST_PHASES.REVERSED_PRACTICE:
        setCurrentPhase(TEST_PHASES.COMBINED_TEST_2);
        startNewTest();
        break;
      case TEST_PHASES.COMBINED_TEST_2:
        // 在進入結果頁面前計算結果
        calculateBiasResults();
        setCurrentPhase(TEST_PHASES.RESULTS);
        break;
      case TEST_PHASES.RESULTS:
        setCurrentPhase(TEST_PHASES.VIDEO);
        break;
      case TEST_PHASES.VIDEO:
        setCurrentPhase(TEST_PHASES.SURVEY);
        break;
      case TEST_PHASES.SURVEY:
        setCurrentPhase(TEST_PHASES.COMPLETED);
        break;
      default:
        setCurrentPhase(TEST_PHASES.START);
    }
  };

  // 開始測試 - 點擊開始測試按鈕時調用
  const startTest = () => {
    setShowInstructions(false);
    selectNextWord();
  };

  // 計算偏見結果 - 使用改良的 D 分數演算法
  const calculateBiasResults = () => {
    const result = calculateDScore(testResults);
    setDScore(result.dScore);
    setBiasLevel(result.biasLevel);

    if (result.biasProduct) {
      setBiasedProduct(result.biasProduct);
      // 產生偏見產品列表
      const products = generateBiasedProducts(result.biasProduct, result.dScore);
      setBiasedProducts(products);
    } else {
      setBiasedProduct('');
      setBiasedProducts([]);
    }

    return result;
  };

  return {
    currentPhase,
    currentWord,
    currentWordType,
    feedback,
    testResults,
    testCount,
    maxTestCount,
    showInstructions,
    biasedProduct,
    biasLevel,
    dScore,
    biasedProducts,
    startNewTest,
    checkAnswer,
    moveToNextPhase,
    startTest,
    calculateBiasResults
  };
};

export default useTestLogic;