import React from 'react';
import { Button, Typography } from 'antd';
import { CheckCircleOutlined } from '@ant-design/icons';

const { Paragraph } = Typography;

interface CompletedPageProps {
  onRestart: () => void;
}

function CompletedPage({ onRestart }: CompletedPageProps) {
  // 不使用 Ant Design 的 Result 元件，而是創建自己的完成頁面樣式
  return (
    <div className="content-container text-center">
      <div className="custom-result success">
        <div className="icon-container">
          <CheckCircleOutlined className="success-icon" />
        </div>
        <h2 className="result-title">測試完成！</h2>
        <div className="result-subtitle">感謝您參與性別商品偏見測試</div>

        <div className="result-extra">
          <Paragraph className="mb-6" style={{ fontSize: '1.125rem', maxWidth: '800px', margin: '0 auto 24px' }}>
            您的參與對於我們了解性別商品偏見現象非常寶貴。希望這次測試能幫助您更好地認識潛在的無意識偏見，並在日常生活中更加關注這一議題。
          </Paragraph>
          <div className="button-container">
            <Button
              type="primary"
              size="large"
              onClick={onRestart}
              icon={<CheckCircleOutlined />}
              className="rounded-button large-button"
            >
              返回首頁
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CompletedPage;