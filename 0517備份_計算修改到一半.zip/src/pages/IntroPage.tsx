import React from 'react';
import { Button, Typography } from 'antd';
import { ExperimentOutlined } from '@ant-design/icons';
import { CustomCard } from '../components/CustomComponents';

const { Title, Paragraph, Text } = Typography;

interface IntroPageProps {
  onStart: () => void;
}

function IntroPage({ onStart }: IntroPageProps) {
  return (
    <div className="content-container text-center">
      <Title level={2} className="mb-6">測試說明</Title>
      <CustomCard className="mb-6" style={{ boxShadow: 'var(--box-shadow)' }}>
        <Title level={4} className="mb-4">測試流程</Title>
        <div style={{ textAlign: 'left' }}>
          <Paragraph className="mb-4">
            <Text strong>1. 分類練習（熟悉反應鍵）</Text><br />
            螢幕上會依序出現詞語，您需用鍵盤快速分類：<br />
            - 左鍵（E）：男性（如：爸爸、男孩）<br />
            - 右鍵（I）：女性（如：女孩、奶奶）
          </Paragraph>
          <Paragraph className="mb-4">
            <Text strong>2. 產品分類練習</Text><br />
            換一組分類，這次是產品類別：<br />
            - 左鍵（E）：電腦類（如：電競滑鼠、顯示卡）<br />
            - 右鍵（I）：護膚類（如：眼霜、乳液）
          </Paragraph>
          <Paragraph className="mb-4">
            <Text strong>3. 聯合分類測試（第一階段）</Text><br />
            現在把人與產品結合起來：<br />
            - 左鍵（E）：男性 + 電腦類<br />
            - 右鍵（I）：女性 + 護膚類
          </Paragraph>
          <Paragraph className="mb-4">
            <Text strong>4. 反向分類練習</Text><br />
            人物分類對調：<br />
            - 左鍵（E）：女性<br />
            - 右鍵（I）：男性
          </Paragraph>
          <Paragraph>
            <Text strong>5. 聯合分類測試（第二階段）</Text><br />
            顛倒之前的配對來測試潛在偏好：<br />
            - 左鍵（E）：女性 + 電腦類<br />
            - 右鍵（I）：男性 + 護膚類
          </Paragraph>
        </div>
      </CustomCard>
      <Paragraph className="mb-6" style={{ fontSize: '1.125rem' }}>
        請盡可能快速且準確地做出反應。測試結果將顯示您可能存在的潛在性別商品偏見。
      </Paragraph>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <Button
          type="primary"
          size="large"
          onClick={onStart}
          icon={<ExperimentOutlined />}
          className="rounded-button large-button"
        >
          開始練習
        </Button>
      </div>
    </div>
  );
}

export default IntroPage;