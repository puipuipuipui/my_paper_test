import React, { useEffect, useRef } from 'react';
import { Button, Typography, Progress } from 'antd';
import { PlayCircleOutlined } from '@ant-design/icons';
import { TestResults } from '../types/testTypes';
import { createResultsChart } from '../utils/chartUtils';
import { CustomCard } from '../components/CustomComponents';

const { Title, Paragraph, Text } = Typography;

interface ResultsPageProps {
  testResults: TestResults;
  biasedProduct: string;
  biasLevel: string;
  dScore: number;
  biasedProducts: Array<{ name: string; score: number }>;
  onContinue: () => void;
}

function ResultsPage({
  testResults,
  biasedProduct,
  biasLevel,
  dScore,
  biasedProducts,
  onContinue
}: ResultsPageProps) {
  const chartRef = useRef(null);

  // 計算平均反應時間並創建圖表
  useEffect(() => {
    // 如果圖表容器不存在，返回一個空的清理函數
    if (!chartRef.current) return () => { };

    // 計算平均反應時間
    const avgMaleComputer = testResults.maleComputer.length > 0 ?
      testResults.maleComputer.reduce((a, b) => a + b, 0) / testResults.maleComputer.length : 0;

    const avgFemaleSkincare = testResults.femaleSkincare.length > 0 ?
      testResults.femaleSkincare.reduce((a, b) => a + b, 0) / testResults.femaleSkincare.length : 0;

    const avgFemaleComputer = testResults.femaleComputer.length > 0 ?
      testResults.femaleComputer.reduce((a, b) => a + b, 0) / testResults.femaleComputer.length : 0;

    const avgMaleSkincare = testResults.maleSkincare.length > 0 ?
      testResults.maleSkincare.reduce((a, b) => a + b, 0) / testResults.maleSkincare.length : 0;

    // 創建圖表
    const cleanupChart = createResultsChart(chartRef.current, {
      avgMaleComputer,
      avgFemaleSkincare,
      avgFemaleComputer,
      avgMaleSkincare
    });

    // 確保返回一個函數，即使 cleanupChart 可能不是函數
    return typeof cleanupChart === 'function' ? cleanupChart : () => { };
  }, [testResults]);

  // 根據 biasedProduct 生成適當的結果解釋
  const getBiasExplanation = () => {
    if (!biasedProduct || biasLevel === '無或極弱偏見') {
      return (
        <Paragraph style={{ fontSize: '1.125rem' }}>
          根據您的反應時間分析，您在不同性別與產品組合的測試中反應時間差異不明顯。
          這表示您可能<Text strong style={{ fontSize: '1.25rem' }}> 沒有明顯的性別商品偏見</Text>，
          或偏見程度非常輕微。
        </Paragraph>
      );
    }

    if (biasedProduct === '電競滑鼠') {
      return (
        <Paragraph style={{ fontSize: '1.125rem' }}>
          根據您的反應時間分析，我們發現您在<Text strong style={{ fontSize: '1.25rem' }}> 女性與電腦類 </Text>
          組合的測試中反應較慢，表示可能存在潛在聯想障礙。這顯示您可能對
          <Text strong style={{ fontSize: '1.25rem' }}> 電競滑鼠 </Text>
          存在<Text strong style={{ fontSize: '1.25rem', color: getBiasLevelColor() }}> {biasLevel} </Text>
          的性別刻板印象，傾向於將其視為更適合男性的產品。
        </Paragraph>
      );
    } else {
      return (
        <Paragraph style={{ fontSize: '1.125rem' }}>
          根據您的反應時間分析，我們發現您在<Text strong style={{ fontSize: '1.25rem' }}> 男性與護膚類 </Text>
          組合的測試中反應較慢，表示可能存在潛在聯想障礙。這顯示您可能對
          <Text strong style={{ fontSize: '1.25rem' }}> 面膜 </Text>
          存在<Text strong style={{ fontSize: '1.25rem', color: getBiasLevelColor() }}> {biasLevel} </Text>
          的性別刻板印象，傾向於將其視為更適合女性的產品。
        </Paragraph>
      );
    }
  };

  // 根據偏見程度獲取顏色
  const getBiasLevelColor = () => {
    switch (biasLevel) {
      case '高度偏見': return '#f5222d'; // 紅色
      case '中度偏見': return '#fa8c16'; // 橙色
      case '輕度偏見': return '#faad14'; // 黃色
      default: return '#52c41a'; // 綠色 (無偏見)
    }
  };

  // 獲取偏見程度的百分比
  const getBiasPercentage = () => {
    const absScore = Math.abs(dScore);
    // 將 D 值轉換為百分比 (0.65+ 視為 100%)
    return Math.min(Math.round(absScore / 0.65 * 100), 100);
  };

  // 獲取進度條的狀態
  const getProgressStatus = () => {
    if (biasLevel === '無或極弱偏見') return 'success';
    if (biasLevel === '輕度偏見') return 'success';
    if (biasLevel === '中度偏見') return 'warning';
    if (biasLevel === '高度偏見') return 'exception';
    return 'normal';
  };

  return (
    <div className="wide-container">
      <Title level={2} className="text-center mb-8">測試結果分析</Title>

      {/* 主要結果卡片 */}
      <div className="mb-8">
        <CustomCard style={{ boxShadow: 'var(--box-shadow)' }}>
          <div className="mb-6">
            <Title level={4}>您的偏見分析</Title>
            {getBiasExplanation()}

            {biasLevel !== '無或極弱偏見' && (
              <div className="mb-4 mt-4">
                <Text strong>偏見強度 (D 值: {dScore.toFixed(2)}):</Text>
                <Progress
                  percent={getBiasPercentage()}
                  status={getProgressStatus() as any}
                  strokeColor={getBiasLevelColor()}
                />
              </div>
            )}
          </div>

          <div ref={chartRef} className="chart-container"></div>

          <Paragraph>
            此圖表顯示了您在不同組合下的平均反應時間（毫秒）。較短的反應時間表示您對這些組合的聯想更為自然，
            而較長的反應時間則可能表示這些組合與您的潛在認知存在衝突。
          </Paragraph>
          <Paragraph>
            <Text strong>左側兩個條形：</Text> 傳統性別商品組合（男性+電腦類、女性+護膚類）<br />
            <Text strong>右側兩個條形：</Text> 非傳統性別商品組合（女性+電腦類、男性+護膚類）
          </Paragraph>
        </CustomCard>
      </div>

      {/* 偏見商品列表卡片 */}
      {biasedProducts.length > 0 && (
        <div className="mb-8">
          <CustomCard style={{ boxShadow: 'var(--box-shadow)' }}>
            <Title level={4}>可能存在性別偏見的產品列表</Title>
            <Paragraph>
              基於您的測試結果，以下產品可能存在與<Text strong>{biasedProduct === '電競滑鼠' ? '女性' : '男性'}</Text>使用相關的偏見：
            </Paragraph>

            <div className="biased-products-list">
              {biasedProducts.map((product, index) => (
                <div key={index} className="biased-product-item">
                  <div className="product-rank">{index + 1}</div>
                  <div className="product-info">
                    <div className="product-name">{product.name}</div>
                    <Progress
                      percent={Math.round(product.score * 100)}
                      size="small"
                      strokeColor={getBiasLevelColor()}
                      showInfo={false}
                    />
                  </div>
                </div>
              ))}
            </div>

            <Paragraph className="mt-4" style={{ fontSize: '0.9rem' }}>
              <Text type="secondary">
                * 產品偏見分數基於您的整體偏見強度和產品類別計算。分數越高表示偏見可能性越大。
              </Text>
            </Paragraph>
          </CustomCard>
        </div>
      )}

      <div className="text-center">
        <Paragraph style={{ fontSize: '1.125rem' }} className="mb-6">
          接下來，我們邀請您觀看一段關於性別商品偏見的短片，以幫助您更好地理解這一現象。
        </Paragraph>
        <div className="button-container">
          <Button
            type="primary"
            size="large"
            onClick={onContinue}
            icon={<PlayCircleOutlined />}
            className="rounded-button large-button"
          >
            觀看影片
          </Button>
        </div>
      </div>
    </div>
  );
}

export default ResultsPage;