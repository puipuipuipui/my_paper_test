import React from 'react';
import { Button, Typography } from 'antd';
import { FormOutlined } from '@ant-design/icons';
import { CustomCard } from '../components/CustomComponents';

const { Title, Paragraph } = Typography;

interface SurveyPageProps {
  onComplete: () => void;
}

function SurveyPage({ onComplete }: SurveyPageProps) {
  return (
    <div className="content-container text-center">
      <Title level={2} className="mb-6">問卷調查</Title>
      <CustomCard className="mb-8">
        <img
          src="https://readdy.ai/api/search-image?query=A%20person%20filling%20out%20a%20survey%20on%20a%20tablet%2C%20with%20thoughtful%20expression.%20Clean%2C%20professional%20setting%20with%20soft%20lighting%2C%20showing%20hands%20interacting%20with%20digital%20survey%20form.%20Modern%20design%20with%20subtle%20technology%20elements&width=600&height=300&seq=2&orientation=landscape"
          alt="問卷調查"
          className="survey-image"
        />
        <Title level={4} className="mb-4">您的反饋對我們很重要</Title>
        <Paragraph className="mb-6" style={{ fontSize: '1.125rem' }}>
          請點擊下方按鈕，完成一份關於性別商品偏見的簡短問卷調查。您的意見將幫助我們改進研究和提高大眾對無意識偏見的認識。
        </Paragraph>
        <Button
          type="primary"
          size="large"
          href="https://forms.example.com/gender-bias-survey" // 替換為實際問卷鏈接
          target="_blank"
          icon={<FormOutlined />}
          className="rounded-button large-button"
        >
          填寫問卷
        </Button>
      </CustomCard>
      <div className="button-container">
        <Button
          type="default"
          size="large"
          onClick={onComplete}
          className="rounded-button"
        >
          完成測試
        </Button>
      </div>
    </div>
  );
}

export default SurveyPage;