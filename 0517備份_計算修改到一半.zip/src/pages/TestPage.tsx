import React, { useEffect } from 'react';
import TestContent from '../components/TestContent';
import { TestPhase, Side, FeedbackType } from '../types/testTypes';

interface TestPageProps {
  currentPhase: TestPhase;
  currentWord: string;
  feedback: FeedbackType; // 修改為 FeedbackType 類型
  testCount: number;
  maxTestCount: number;
  showInstructions: boolean;
  onCheckAnswer: (side: Side) => void;
  onStartTest: () => void;
}

function TestPage({
  currentPhase,
  currentWord,
  feedback,
  testCount,
  maxTestCount,
  showInstructions,
  onCheckAnswer,
  onStartTest
}: TestPageProps) {
  // 監聽鍵盤事件
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (showInstructions) return;
      
      if (e.key === 'e' || e.key === 'E') {
        onCheckAnswer('left');
      } else if (e.key === 'i' || e.key === 'I') {
        onCheckAnswer('right');
      }
    };
    
    window.addEventListener('keydown', handleKeyPress);
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, [onCheckAnswer, showInstructions]);

  return (
    <TestContent
      currentPhase={currentPhase}
      currentWord={currentWord}
      feedback={feedback}
      testCount={testCount}
      maxTestCount={maxTestCount}
      showInstructions={showInstructions}
      onStartTest={onStartTest}
    />
  );
}

export default TestPage;