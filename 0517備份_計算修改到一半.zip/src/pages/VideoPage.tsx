import React from 'react';
import { Button, Typography } from 'antd';
import { FormOutlined } from '@ant-design/icons';

const { Title, Paragraph } = Typography;

interface VideoPageProps {
  onContinue: () => void;
}

function VideoPage({ onContinue }: VideoPageProps) {
  // 移除 ref，因為實際上沒有使用它

  return (
    <div className="wide-container">
      <Title level={2} className="text-center mb-6">觀看影片</Title>
      <Paragraph className="text-center mb-6" style={{ fontSize: '1.125rem' }}>
        請觀看以下關於性別商品偏見的短片，了解更多相關信息。
      </Paragraph>
      <div className="video-container">
        <iframe
          src="https://www.youtube.com/embed/dQw4w9WgXcQ" // 替換為實際視頻鏈接
          title="性別商品偏見影片"
          className="video-iframe"
          allowFullScreen
        ></iframe>
      </div>
      <div className="text-center">
        <Paragraph className="mb-6" style={{ fontSize: '1.125rem' }}>
          觀看完影片後，請完成一份簡短的問卷調查，分享您的想法和反饋。
        </Paragraph>
        <div className="button-container">
          <Button
            type="primary"
            size="large"
            onClick={onContinue}
            icon={<FormOutlined />}
            className="rounded-button large-button"
          >
            前往問卷調查
          </Button>
        </div>
      </div>
    </div>
  );
}

export default VideoPage;