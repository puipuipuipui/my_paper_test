import { TestResults } from '../types/testTypes';
import { maleWords, femaleWords, computerWords, skinCareWords } from '../constants/testConstants';

/**
 * 根據 IAT 改良 D 分數演算法計算偏見強度
 * @param testResults 測試結果數據
 * @returns D值和偏見強度級別
 */
export const calculateDScore = (testResults: TestResults) => {
    // 步驟 1: 資料前處理 (已在收集數據時處理)

    // 步驟 2: 計算平均反應時間
    // 合併「一致」區塊
    const congruentTimes = [...testResults.maleComputer, ...testResults.femaleSkincare];
    const meanCongruent = congruentTimes.length > 0
        ? congruentTimes.reduce((sum, time) => sum + time, 0) / congruentTimes.length
        : 0;

    // 合併「不一致」區塊
    const incongruentTimes = [...testResults.femaleComputer, ...testResults.maleSkincare];
    const meanIncongruent = incongruentTimes.length > 0
        ? incongruentTimes.reduce((sum, time) => sum + time, 0) / incongruentTimes.length
        : 0;

    // 步驟 3: 計算所有區塊的合併標準差
    const allTimes = [...congruentTimes, ...incongruentTimes];
    if (allTimes.length <= 1) return { dScore: 0, biasLevel: '無偏見', biasProduct: null };

    // 計算標準差
    const mean = allTimes.reduce((sum, time) => sum + time, 0) / allTimes.length;
    const squareDiffs = allTimes.map(time => Math.pow(time - mean, 2));
    const variance = squareDiffs.reduce((sum, diff) => sum + diff, 0) / (allTimes.length - 1);
    const standardDeviation = Math.sqrt(variance);

    // 步驟 4: 計算 D 值
    // D = (Mean_incongruent - Mean_congruent) / SD_all
    const dScore = (meanIncongruent - meanCongruent) / standardDeviation;

    // 步驟 5: 解讀 D 值
    let biasLevel = '';
    let biasProduct = null;

    if (Math.abs(dScore) < 0.15) {
        biasLevel = '無或極弱偏見';
        biasProduct = null;
    } else {
        // 判斷偏好方向
        if (dScore > 0) {
            // 正值表示對傳統配對有偏好 (反應較快)
            // 這表示對非傳統配對有偏見 (反應較慢)
            biasProduct = '電競滑鼠'; // 對女性使用電競滑鼠有偏見

            if (dScore >= 0.65) {
                biasLevel = '高度偏見';
            } else if (dScore >= 0.35) {
                biasLevel = '中度偏見';
            } else {
                biasLevel = '輕度偏見';
            }
        } else {
            // 負值表示對非傳統配對有偏好 (反應較快)
            // 這表示對傳統配對有偏見 (反應較慢)
            biasProduct = '面膜'; // 對男性使用面膜有偏見

            if (dScore <= -0.65) {
                biasLevel = '高度偏見';
            } else if (dScore <= -0.35) {
                biasLevel = '中度偏見';
            } else {
                biasLevel = '輕度偏見';
            }
        }
    }

    return {
        dScore,
        biasLevel,
        biasProduct,
        meanCongruent,
        meanIncongruent,
        standardDeviation
    };
};

/**
 * 產生全部具有偏見的產品列表，按偏見程度排序
 * @param biasType 偏見類型 (面膜/電競滑鼠)
 * @param biasStrength 偏見強度
 * @returns 產品列表
 */
export const generateBiasedProducts = (biasType: string | null, biasStrength: number) => {
    if (!biasType || Math.abs(biasStrength) < 0.15) {
        return [];
    }

    // 強度係數 (用於排序)
    const strengthCoefficient = Math.min(Math.abs(biasStrength), 1);

    // 產品列表 - 使用測試中的實際產品
    const productWeights: {[key: string]: number} = {
        // 電腦類產品
        '電競滑鼠': 1.0,
        '機械鍵盤': 0.95,
        '曲面螢幕': 0.9,
        '顯示卡': 0.85,
        '水冷散熱器': 0.8,

        // 護膚類產品
        '面膜': 1.0,
        '精華液': 0.95,
        '保濕霜': 0.9,
        '眼霜': 0.85,
        '乳液': 0.8
    };

    // 根據偏見類型選擇要顯示的產品列表
    let products = [];

    if (biasType === '電競滑鼠') {
        // 對女性使用電腦類產品有偏見，顯示電腦類產品
        products = computerWords.map(product => ({
            name: product,
            score: (productWeights[product] || 0.7) * strengthCoefficient
        }));
    } else {
        // 對男性使用護膚類產品有偏見，顯示護膚類產品
        products = skinCareWords.map(product => ({
            name: product,
            score: (productWeights[product] || 0.7) * strengthCoefficient
        }));
    }

    // 按分數降序排序
    return products.sort((a, b) => b.score - a.score);
};