import * as echarts from 'echarts/core';

export interface ChartData {
  avgMaleComputer: number;
  avgFemaleSkincare: number;
  avgFemaleComputer: number;
  avgMaleSkincare: number;
}

export const createResultsChart = (chartElement: HTMLDivElement, data: ChartData): (() => void) => {
  if (!chartElement) return () => {}; // 確保返回一個清理函數
  
  const chart = echarts.init(chartElement);
  
  // 計算最大值以設置 y 軸範圍
  const maxValue = Math.max(
    data.avgMaleComputer,
    data.avgFemaleSkincare,
    data.avgFemaleComputer,
    data.avgMaleSkincare
  ) * 1.2; // 增加 20% 的空間
  
  const option = {
    animation: false,
    title: {
      text: '反應時間分析 (毫秒)',
      left: 'center',
      textStyle: {
        fontSize: 16
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      },
      formatter: function(params: any) {
        const dataIndex = params[0].dataIndex;
        let explanation = '';
        
        switch(dataIndex) {
          case 0:
            explanation = '男性+電腦: 傳統組合，反應時間較短表示對此組合接受度高';
            break;
          case 1:
            explanation = '女性+護膚: 傳統組合，反應時間較短表示對此組合接受度高';
            break;
          case 2:
            explanation = '女性+電腦: 非傳統組合，反應時間較長表示可能存在偏見';
            break;
          case 3:
            explanation = '男性+護膚: 非傳統組合，反應時間較長表示可能存在偏見';
            break;
        }
        
        return params[0].name + '<br/>' + 
               params[0].marker + ' 反應時間: ' + params[0].value + ' ms<br/>' +
               '<div style="margin-top:5px;font-size:12px;color:#999;">' + explanation + '</div>';
      }
    },
    legend: {
      data: ['傳統性別組合', '非傳統性別組合'],
      bottom: '0%'
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '15%',
      top: '15%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: ['男性+電腦', '女性+護膚', '女性+電腦', '男性+護膚'],
      axisLabel: {
        interval: 0,
        rotate: 0,
        formatter: function(value: string) {
          // 為標籤添加換行以提高可讀性
          return value.replace('+', '+\n');
        }
      }
    },
    yAxis: {
      type: 'value',
      name: '反應時間 (ms)',
      min: 0,
      max: maxValue
    },
    series: [
      {
        name: '反應時間',
        type: 'bar',
        data: [
          { 
            value: data.avgMaleComputer, 
            itemStyle: { color: '#91cc75' },
            tooltip: { formatter: '傳統組合: 男性與電腦類' }
          },
          { 
            value: data.avgFemaleSkincare, 
            itemStyle: { color: '#91cc75' },
            tooltip: { formatter: '傳統組合: 女性與護膚類' }
          },
          { 
            value: data.avgFemaleComputer, 
            itemStyle: { color: '#ee6666' },
            tooltip: { formatter: '非傳統組合: 女性與電腦類' }
          },
          { 
            value: data.avgMaleSkincare, 
            itemStyle: { color: '#ee6666' },
            tooltip: { formatter: '非傳統組合: 男性與護膚類' }
          }
        ],
        label: {
          show: true,
          position: 'top',
          formatter: '{c} ms'
        },
        markLine: {
          data: [
            {
              name: '平均反應時間',
              type: 'average',
              lineStyle: {
                color: '#73c0de',
                type: 'dashed'
              },
              label: {
                position: 'end',
                formatter: '平均: {c} ms'
              }
            }
          ]
        }
      }
    ]
  };
    
  chart.setOption(option);
  
  // 響應窗口大小變化
  const resizeHandler = () => {
    chart.resize();
  };
  
  window.addEventListener('resize', resizeHandler);
  
  // 返回清理函數
  return () => {
    chart.dispose();
    window.removeEventListener('resize', resizeHandler);
  };
};